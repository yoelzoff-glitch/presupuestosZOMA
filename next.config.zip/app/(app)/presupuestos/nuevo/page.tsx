'use client'

import { useEffect, useMemo, useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabase/client'
import { fetchNextNumber } from '@/lib/fetchNextNumber'
import { toast } from 'sonner'
import {
  ArrowLeft,
  FileText,
  Plus,
  Save,
  Search,
  Trash2,
  User,
  Package,
  Hash,
  Tag,
  DollarSign,
  Calculator,
  Zap,
} from 'lucide-react'

type Client = {
  id: string
  name: string
  cuit: string
}

type Product = {
  id: string
  internal_code: string | null
  name: string
  category: string | null
  cost_price: number
  sale_price: number
}

type BudgetItem = {
  product_id: string | null
  code: string
  name: string
  category: string
  price: number
  quantity: number
  discount_str?: string // Para guardar el registro del descuento aplicado
}

export default function NuevoPresupuestoPage() {
  const router = useRouter()

  const [companyId, setCompanyId] = useState<string | null>(null)
  const [cascadingEnabled, setCascadingEnabled] = useState(false)
  const [clients, setClients] = useState<Client[]>([])
  const [products, setProducts] = useState<Product[]>([])
  const [items, setItems] = useState<BudgetItem[]>([])

  const [clientId, setClientId] = useState('')
  const [search, setSearch] = useState('')
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)

  const [productQty, setProductQty] = useState('1')
  const [productPrice, setProductPrice] = useState('')
  const [productDiscount, setProductDiscount] = useState('')

  const [manual, setManual] = useState({
    code: '',
    name: '',
    category: '',
    price: '',
    quantity: '1',
    discount: '',
  })
  const [budgetNotes, setBudgetNotes] = useState('')

  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    loadData()
  }, [])

  async function getUserContext() {
    const { data: userData } = await supabase.auth.getUser()

    if (!userData.user) return null

    const { data: profile } = await supabase
      .from('users_profiles')
      .select('company_id, role')
      .eq('id', userData.user.id)
      .single()

    return { 
      companyId: profile?.company_id ?? null,
      role: profile?.role ?? null,
      userId: userData.user.id
    }
  }

  async function loadData() {
    setLoading(true)

    const context = await getUserContext()
    const currentCompanyId = context?.companyId
    setCompanyId(currentCompanyId || null)

    if (!currentCompanyId) {
      toast.error('No se encontró la empresa del usuario.')
      setLoading(false)
      return
    }

    // Cargar config de empresa para descuentos en cascada y notas
    const { data: companyData } = await supabase
      .from('companies')
      .select('enable_cascading_discounts, default_notes')
      .eq('id', currentCompanyId)
      .single()
    
    setCascadingEnabled(companyData?.enable_cascading_discounts ?? false)
    setBudgetNotes(companyData?.default_notes || 'Validez: 15 días.\nPrecios sujetos a cambio.')

    const clientsQuery = supabase
      .from('clients')
      .select('id, name, cuit')
      .eq('company_id', currentCompanyId)

    const [clientsRes, productsRes] = await Promise.all([
      clientsQuery.order('name', { ascending: true }),

      supabase
        .from('products')
        .select('id, internal_code, name, category, cost_price, sale_price')
        .eq('company_id', currentCompanyId)
        .eq('show_in_catalog', true)
        .order('name', { ascending: true })
        .range(0, 4999),
    ])

    if (clientsRes.error) toast.error(clientsRes.error.message)
    if (productsRes.error) toast.error(productsRes.error.message)

    if (clientsRes.data) setClients(clientsRes.data)
    if (productsRes.data) setProducts(productsRes.data)

    setLoading(false)
  }

  // Función mágica para calcular descuentos en cascada
  function calculateCascadingPrice(basePrice: number, discountStr: string): number {
    if (!discountStr.trim()) return basePrice
    
    // Divide por +, - o espacios
    const discounts = discountStr
      .split(/[+\-\s]+/)
      .map(d => parseFloat(d.replace(',', '.')))
      .filter(d => !isNaN(d) && d !== 0)

    let finalPrice = basePrice
    for (const d of discounts) {
      // Aplicamos descuento sucesivo y limitamos a 100% para evitar valores negativos
      const clampedD = Math.min(Math.max(d, 0), 100)
      finalPrice = finalPrice * (1 - clampedD / 100)
    }
    return Math.max(0, finalPrice)
  }

  // Efecto para actualizar el precio del producto seleccionado cuando cambia el descuento
  useEffect(() => {
    if (selectedProduct && cascadingEnabled) {
      const basePrice = selectedProduct.sale_price || selectedProduct.cost_price || 0
      const discounted = calculateCascadingPrice(basePrice, productDiscount)
      setProductPrice(discounted.toFixed(2))
    }
  }, [productDiscount, selectedProduct, cascadingEnabled])

  const filteredProducts = useMemo(() => {
    const q = search.toLowerCase().trim()

    if (!q) return []

    return products
      .filter((p) => {
        return (
          p.name?.toLowerCase().includes(q) ||
          p.internal_code?.toLowerCase().includes(q) ||
          p.category?.toLowerCase().includes(q)
        )
      })
      .slice(0, 12)
  }, [products, search])

  const selectedClient = clients.find((c) => c.id === clientId)

  const total = items.reduce(
    (acc, item) => acc + item.price * item.quantity,
    0
  )

  const canSave = Boolean(companyId && clientId && items.length > 0 && !saving)

  const saveButtonText = saving
    ? 'Guardando...'
    : !clientId
      ? 'Seleccioná un cliente'
      : items.length === 0
        ? 'Agregá productos'
        : 'Guardar presupuesto'

  function selectProduct(product: Product) {
    setSelectedProduct(product)
    setProductQty('1')
    setProductPrice(String(product.sale_price || product.cost_price || 0))
    setProductDiscount('')
  }

  function addProductItem() {
    if (!selectedProduct) {
      toast.error('Seleccioná un producto.')
      return
    }

    const quantity = Number(productQty)
    const price = Number(productPrice)

    if (!quantity || quantity <= 0) {
      toast.error('Ingresá una cantidad válida.')
      return
    }

    if (Number.isNaN(price) || price < 0) {
      toast.error('Ingresá un precio válido.')
      return
    }

    if (cascadingEnabled && productDiscount.trim()) {
      const discounts = productDiscount.split(/[+\-\s]+/).map(d => parseFloat(d.replace(',', '.'))).filter(d => !isNaN(d))
      if (discounts.some(d => d > 100)) {
        toast.error('Ningún descuento individual puede ser mayor al 100%.')
        return
      }
    }

    setItems((prev) => [
      ...prev,
      {
        product_id: selectedProduct.id,
        code: selectedProduct.internal_code || '',
        name: selectedProduct.name,
        category: selectedProduct.category || '',
        price,
        quantity,
        discount_str: cascadingEnabled ? productDiscount : undefined
      },
    ])

    setSelectedProduct(null)
    setSearch('')
    setProductQty('1')
    setProductPrice('')
    setProductDiscount('')
  }

  function addManualItem() {
    const quantity = Number(manual.quantity)
    let price = Number(manual.price)

    if (!manual.name.trim()) {
      toast.error('Ingresá el nombre del producto.')
      return
    }

    if (!quantity || quantity <= 0) {
      toast.error('Ingresá una cantidad válida.')
      return
    }

    // Si hay descuento manual en cascada, lo aplicamos al precio manual antes de guardar
    if (cascadingEnabled && manual.discount.trim()) {
      const discounts = manual.discount.split(/[+\-\s]+/).map(d => parseFloat(d.replace(',', '.'))).filter(d => !isNaN(d))
      if (discounts.some(d => d > 100)) {
        toast.error('Ningún descuento individual puede ser mayor al 100%.')
        return
      }
      price = calculateCascadingPrice(price, manual.discount)
    }

    if (Number.isNaN(price) || price < 0) {
      toast.error('Ingresá un precio válido.')
      return
    }

    setItems((prev) => [
      ...prev,
      {
        product_id: null,
        code: manual.code.trim(),
        name: manual.name.trim(),
        category: manual.category.trim(),
        price,
        quantity,
        discount_str: cascadingEnabled ? manual.discount : undefined
      },
    ])

    setManual({
      code: '',
      name: '',
      category: '',
      price: '',
      quantity: '1',
      discount: '',
    })
  }

  function removeItem(index: number) {
    setItems((prev) => prev.filter((_, i) => i !== index))
  }

  function updateItem(index: number, field: 'quantity' | 'price', value: string) {
    const numericValue = Number(value)

    setItems((prev) =>
      prev.map((item, i) =>
        i === index
          ? {
              ...item,
              [field]: Number.isNaN(numericValue) ? 0 : numericValue,
            }
          : item
      )
    )
  }


  async function saveBudget() {
    if (!companyId) {
      toast.error('No se encontró la empresa del usuario.')
      return
    }

    if (!clientId) {
      toast.error('Seleccioná un cliente.')
      return
    }

    if (items.length === 0) {
      toast.error('Agregá al menos un producto.')
      return
    }

    setSaving(true)

    try {
      const context = await getUserContext()
      if (!context?.companyId) throw new Error('Empresa no encontrada')

      const nextNumber = await fetchNextNumber('budget')

      // 1. Create Budget
      const { data: budget, error: budgetError } = await supabase
        .from('budgets')
        .insert({
          company_id: context.companyId,
          client_id: clientId,
          budget_number: nextNumber,
          total_amount: total,
          status: 'issued',
          seller_id: context.role === 'vendedor' ? context.userId : null,
          notes: budgetNotes.trim() || null
        })
        .select('id')
        .single()

      if (budgetError) throw budgetError
      if (!budget?.id) throw new Error('No se pudo crear el presupuesto.')

      const itemsToInsert = items.map((item) => ({
        company_id: companyId,
        budget_id: budget.id,
        product_id: item.product_id,
        product_code: item.code,
        product_name: item.name,
        category: item.category,
        quantity: item.quantity,
        unit_price: item.price,
        discount_str: item.discount_str || null
      }))

      const { error: itemsError } = await supabase
        .from('budget_items')
        .insert(itemsToInsert)

      if (itemsError) throw itemsError

      toast.success(`Presupuesto 000-${nextNumber} creado correctamente.`)

      router.push(`/presupuestos/${budget.id}`)
    } catch (error: any) {
      toast.error(error.message || 'Error al guardar presupuesto.')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="space-y-6">
      <section className="relative overflow-hidden rounded-[2rem] bg-slate-950 p-7 text-white shadow-xl">
        <div className="absolute right-0 top-0 h-44 w-44 rounded-full bg-blue-500/20 blur-3xl" />
        <div className="absolute bottom-0 left-16 h-40 w-40 rounded-full bg-cyan-400/10 blur-3xl" />

        <div className="relative z-10 flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <Link
              href="/presupuestos"
              className="mb-4 inline-flex items-center gap-2 text-sm font-bold text-blue-200 transition hover:text-white"
            >
              <ArrowLeft size={17} />
              Volver a presupuestos
            </Link>

            <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/10 px-3 py-1 text-xs font-bold uppercase tracking-widest text-blue-200">
              <FileText size={14} />
              Nuevo presupuesto
            </div>

            <h1 className="text-3xl font-black tracking-tight">
              Crear presupuesto
            </h1>

            <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-300">
              Seleccioná cliente, agregá productos del listado o cargalos
              manualmente.
            </p>
          </div>

          <button
            type="button"
            onClick={saveBudget}
            disabled={!canSave}
            className="inline-flex items-center justify-center gap-2 rounded-2xl bg-blue-600 px-5 py-3 text-sm font-black text-white shadow-lg shadow-blue-900/30 transition hover:bg-blue-500 disabled:cursor-not-allowed disabled:opacity-60"
          >
            <Save size={18} />
            {saveButtonText}
          </button>
        </div>
      </section>

      <section className="grid gap-6 lg:grid-cols-5">
        <div className="space-y-6 lg:col-span-3">
          <section className="rounded-[1.5rem] border border-slate-200 bg-white p-6 shadow-sm">
            <div className="mb-5 flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-blue-50 text-blue-700">
                <User size={22} />
              </div>

              <div>
                <h2 className="text-xl font-black text-slate-950">
                  Cliente
                </h2>
                <p className="text-sm text-slate-500">
                  Elegí el cliente para este presupuesto.
                </p>
              </div>
            </div>

            <select
              value={clientId}
              disabled={loading}
              onChange={(e) => setClientId(e.target.value)}
              className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-semibold text-slate-700 outline-none transition focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100 disabled:cursor-not-allowed disabled:opacity-60"
            >
              <option value="">
                {loading ? 'Cargando clientes...' : 'Seleccionar cliente'}
              </option>
              {clients.map((client) => (
                <option key={client.id} value={client.id}>
                  {client.name} - CUIT {client.cuit}
                </option>
              ))}
            </select>

            {selectedClient && (
              <div className="mt-4 rounded-2xl bg-slate-50 p-4">
                <p className="text-xs font-black uppercase tracking-widest text-slate-400">
                  Cliente seleccionado
                </p>
                <p className="mt-1 font-black text-slate-950">
                  {selectedClient.name}
                </p>
                <p className="text-sm font-semibold text-slate-500">
                  CUIT: {selectedClient.cuit}
                </p>
              </div>
            )}
          </section>

          <section className="rounded-[1.5rem] border border-slate-200 bg-white p-6 shadow-sm">
            <div className="mb-5 flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-blue-50 text-blue-700">
                <Package size={22} />
              </div>

              <div>
                <h2 className="text-xl font-black text-slate-950">
                  Agregar producto del listado
                </h2>
                <p className="text-sm text-slate-500">
                  Buscá por código, nombre o categoría.
                </p>
              </div>
            </div>

            <div className="relative">
              <Search
                size={18}
                className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"
              />

              <input
                value={search}
                disabled={loading}
                onChange={(e) => {
                  setSearch(e.target.value)
                  setSelectedProduct(null)
                }}
                placeholder={
                  loading ? 'Cargando productos...' : 'Buscar producto...'
                }
                className="w-full rounded-2xl border border-slate-200 bg-slate-50 py-3 pl-11 pr-4 text-sm font-semibold text-slate-700 outline-none transition focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100 disabled:cursor-not-allowed disabled:opacity-60"
              />
            </div>

            {search && filteredProducts.length === 0 && !selectedProduct && (
              <div className="mt-3 rounded-2xl border border-slate-200 bg-slate-50 p-4 text-sm font-semibold text-slate-500">
                No se encontraron productos con esa búsqueda.
              </div>
            )}

            {search && filteredProducts.length > 0 && !selectedProduct && (
              <div className="mt-3 max-h-72 overflow-auto rounded-2xl border border-slate-200">
                {filteredProducts.map((product) => (
                  <button
                    key={product.id}
                    type="button"
                    onClick={() => selectProduct(product)}
                    className="flex w-full items-center justify-between gap-4 border-b border-slate-100 p-4 text-left transition last:border-b-0 hover:bg-blue-50"
                  >
                    <div>
                      <p className="font-black text-slate-950">
                        {product.name}
                      </p>

                      <div className="mt-1 flex flex-wrap gap-2 text-xs font-bold text-slate-500">
                        <span>Código: {product.internal_code || '-'}</span>
                        <span>•</span>
                        <span>{product.category || 'Sin categoría'}</span>
                      </div>
                    </div>

                    <p className="shrink-0 font-black text-blue-700">
                      ${Number(product.sale_price || product.cost_price || 0).toLocaleString('es-AR')}
                    </p>
                  </button>
                ))}
              </div>
            )}

            {selectedProduct && (
              <div className="mt-5 rounded-3xl border border-blue-100 bg-blue-50/50 p-5">
                <div className="flex items-center justify-between">
                  <p className="text-xs font-black uppercase tracking-widest text-blue-500">
                    Producto seleccionado
                  </p>
                  {cascadingEnabled && (
                    <div className="flex items-center gap-1 rounded-lg bg-blue-600 px-2 py-1 text-[10px] font-black uppercase text-white shadow-lg shadow-blue-600/20">
                      <Zap size={10} />
                      Cascada ON
                    </div>
                  )}
                </div>

                <h3 className="mt-2 text-xl font-black text-slate-950">
                  {selectedProduct.name}
                </h3>

                <div className="mt-3 grid gap-3 text-sm font-semibold text-slate-600 sm:grid-cols-3">
                  <Info
                    icon={Hash}
                    label="Código"
                    value={selectedProduct.internal_code || '-'}
                  />
                  <Info
                    icon={Tag}
                    label="Categoría"
                    value={selectedProduct.category || '-'}
                  />
                  <Info
                    icon={DollarSign}
                    label="Precio lista"
                    value={`$${Number(
                      selectedProduct.sale_price || selectedProduct.cost_price || 0
                    ).toLocaleString('es-AR')}`}
                  />
                </div>

                <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                  <Field
                    label="Cantidad"
                    value={productQty}
                    onChange={setProductQty}
                    type="number"
                  />

                  {cascadingEnabled && (
                    <div className="relative group">
                      <label className="mb-2 block text-sm font-black text-slate-700">
                        Descuento (%)
                      </label>
                      <input
                        value={productDiscount}
                        onChange={(e) => setProductDiscount(e.target.value)}
                        placeholder="10+10+5"
                        className="w-full rounded-2xl border border-blue-200 bg-white px-4 py-3 text-sm font-black text-blue-700 outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-100"
                      />
                      <Zap size={14} className="absolute right-4 top-[2.6rem] text-blue-400 group-focus-within:text-blue-600" />
                    </div>
                  )}

                  <Field
                    label="Precio unitario final"
                    value={productPrice}
                    onChange={setProductPrice}
                    type="number"
                    disabled={cascadingEnabled && !!productDiscount}
                  />

                  <div>
                    <label className="mb-2 block text-sm font-black text-slate-700">
                      Subtotal
                    </label>
                    <div className="rounded-2xl border border-slate-200 bg-slate-100/50 px-4 py-3 text-sm font-black text-slate-900">
                      $
                      {(
                        Number(productQty || 0) * Number(productPrice || 0)
                      ).toLocaleString('es-AR')}
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={addProductItem}
                  className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-blue-600 px-5 py-3 text-sm font-black text-white shadow-lg shadow-blue-900/20 transition hover:bg-blue-500"
                >
                  <Plus size={18} />
                  Agregar al presupuesto
                </button>
              </div>
            )}
          </section>

          <section className="rounded-[1.5rem] border border-slate-200 bg-white p-6 shadow-sm">
            <div className="mb-5">
              <h2 className="text-xl font-black text-slate-950">
                Agregar producto manual
              </h2>
              <p className="text-sm text-slate-500">
                Para productos que no están cargados en la lista.
              </p>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <Field
                label="Código"
                value={manual.code}
                onChange={(v) => setManual({ ...manual, code: v })}
              />

              <Field
                label="Categoría"
                value={manual.category}
                onChange={(v) => setManual({ ...manual, category: v })}
              />

              <div className="md:col-span-2">
                <Field
                  label="Producto"
                  value={manual.name}
                  onChange={(v) => setManual({ ...manual, name: v })}
                />
              </div>

              <Field
                label="Precio lista / base"
                value={manual.price}
                onChange={(v) => setManual({ ...manual, price: v })}
                type="number"
              />

              {cascadingEnabled && (
                <Field
                  label="Descuento (%)"
                  value={manual.discount}
                  onChange={(v) => setManual({ ...manual, discount: v })}
                  placeholder="Ej: 10+5"
                />
              )}

              <Field
                label="Cantidad"
                value={manual.quantity}
                onChange={(v) => setManual({ ...manual, quantity: v })}
                type="number"
              />
            </div>

            <button
              type="button"
              onClick={addManualItem}
              className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-slate-950 px-5 py-3 text-sm font-black text-white transition hover:bg-slate-800"
            >
              <Plus size={18} />
              Agregar producto manual
            </button>
          </section>

          <section className="rounded-[1.5rem] border border-slate-200 bg-white p-6 shadow-sm">
            <h2 className="text-xl font-black text-slate-950 mb-4 flex items-center gap-2">
              <FileText size={20} className="text-blue-600" /> Condiciones y Notas
            </h2>
            <p className="text-sm text-slate-500 mb-4 font-semibold">
              Escribí los términos legales o comerciales que aparecerán en el PDF.
            </p>
            <textarea
              value={budgetNotes}
              onChange={(e) => setBudgetNotes(e.target.value)}
              rows={8}
              className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-bold text-slate-800 outline-none transition focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100"
              placeholder="Ej: Validez del presupuesto..."
            />
          </section>
        </div>

        <aside className="space-y-6 lg:col-span-2">
          <section className="sticky top-24 rounded-[1.5rem] border border-slate-200 bg-white shadow-sm overflow-hidden">
            <div className="border-b border-slate-200 bg-slate-50/50 p-6">
              <div className="flex items-center gap-3">
                <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-blue-600 text-white shadow-lg shadow-blue-600/20">
                  <Calculator size={22} />
                </div>

                <div>
                  <h2 className="text-xl font-black text-slate-950">
                    Resumen
                  </h2>
                  <p className="text-sm font-bold text-slate-500">
                    {items.length} {items.length === 1 ? 'ítem' : 'ítems'} agregados
                  </p>
                </div>
              </div>
            </div>

            {items.length === 0 ? (
              <div className="p-10 text-center">
                <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-[2rem] bg-slate-100 text-slate-300">
                  <FileText size={32} />
                </div>
                <h3 className="font-black text-slate-400">
                  No hay productos
                </h3>
              </div>
            ) : (
              <div className="max-h-[50vh] overflow-y-auto divide-y divide-slate-100 custom-scrollbar">
                {items.map((item, index) => (
                  <div key={index} className="group p-5 transition hover:bg-slate-50/50">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0 flex-1">
                        <p className="truncate font-black text-slate-950">
                          {item.name}
                        </p>
                        <div className="mt-1 flex items-center gap-2">
                          <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">
                            {item.code || 'S/C'}
                          </span>
                          {item.discount_str && (
                            <span className="inline-flex items-center gap-1 rounded-md bg-blue-50 px-1.5 py-0.5 text-[10px] font-black text-blue-600">
                              <Zap size={10} />
                              -{item.discount_str}%
                            </span>
                          )}
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => removeItem(index)}
                        className="rounded-xl p-2 text-slate-300 transition hover:bg-red-50 hover:text-red-600"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>

                    <div className="mt-4 flex items-center justify-between rounded-2xl border border-slate-100 bg-white p-3 shadow-sm">
                      <div className="text-center">
                        <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Cant</p>
                        <p className="text-sm font-black text-slate-900">{item.quantity}</p>
                      </div>
                      <div className="h-4 w-px bg-slate-100" />
                      <div className="text-center">
                        <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">P. Unit</p>
                        <p className="text-sm font-black text-slate-900">${item.price.toLocaleString('es-AR')}</p>
                      </div>
                      <div className="h-4 w-px bg-slate-100" />
                      <div className="text-right">
                        <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Subtotal</p>
                        <p className="text-sm font-black text-blue-600">${(item.price * item.quantity).toLocaleString('es-AR')}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div className="border-t-2 border-slate-100 bg-slate-50 p-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <p className="text-xs font-black uppercase tracking-widest text-slate-400">Total presupuesto</p>
                  <p className="text-sm font-bold text-slate-500">Impuestos incluidos</p>
                </div>
                <p className="text-4xl font-black tracking-tight text-slate-950">
                  ${total.toLocaleString('es-AR')}
                </p>
              </div>

              <button
                type="button"
                onClick={saveBudget}
                disabled={!canSave}
                className="inline-flex w-full items-center justify-center gap-3 rounded-2xl bg-blue-600 px-6 py-4 text-sm font-black text-white shadow-xl shadow-blue-900/20 transition hover:bg-blue-700 hover:-translate-y-0.5 active:scale-95 disabled:cursor-not-allowed disabled:opacity-60"
              >
                <Save size={20} />
                {saveButtonText}
              </button>
            </div>
          </section>
        </aside>
      </section>
    </div>
  )
}

function Field({
  label,
  value,
  onChange,
  type = 'text',
  placeholder = '',
  disabled = false,
}: {
  label: string
  value: string
  onChange: (value: string) => void
  type?: string
  placeholder?: string
  disabled?: boolean
}) {
  return (
    <div>
      <label className="mb-2 block text-sm font-black text-slate-700">
        {label}
      </label>

      <input
        type={type}
        value={value}
        disabled={disabled}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-bold text-slate-700 outline-none transition focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100 disabled:bg-slate-100 disabled:text-slate-400"
      />
    </div>
  )
}

function Info({
  icon: Icon,
  label,
  value,
}: {
  icon: any
  label: string
  value: string
}) {
  return (
    <div className="flex items-center gap-3 rounded-2xl bg-white p-3 shadow-sm border border-slate-100">
      <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-blue-50 text-blue-600">
        <Icon size={16} />
      </div>
      <div>
        <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 leading-none mb-1">
          {label}
        </p>
        <p className="text-xs font-black text-slate-900 truncate">
          {value}
        </p>
      </div>
    </div>
  )
}