import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  'https://ytqdzfmlbdomidnpvelg.supabase.co',
  'sb_publishable_n49wA8JdZCfiaWi50Nox9Q_j687t-uE'
)

async function test() {
  const { data, error } = await supabase.from('budgets').select('id, status, company_id')
  console.log('Total budgets visible to anon:', data?.length)
  console.log('Statuses:', [...new Set(data?.map(d => d.status))])
}

test()
