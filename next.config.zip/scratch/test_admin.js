import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  'https://ytqdzfmlbdomidnpvelg.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inl0cWR6Zm1sYmRvbWlkbnB2ZWxnIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3ODU2MDY2OCwiZXhwIjoyMDk0MTM2NjY4fQ.MynN3LB9CALs0vswgTHR1SW2CVK7C9gyAbQX3WaYbrc'
)

async function test() {
  const { data, error } = await supabase.from('budgets').select('id, status, created_at, budget_number').order('created_at', { ascending: false }).limit(5)
  console.log('Admin read data:', data)
}

test()
