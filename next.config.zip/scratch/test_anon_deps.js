import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  'https://ytqdzfmlbdomidnpvelg.supabase.co',
  'sb_publishable_n49wA8JdZCfiaWi50Nox9Q_j687t-uE'
)

async function test() {
  const { data: budget } = await supabase.from('budgets').select('id, company_id').limit(1).single()
  console.log('budget:', budget)

  const { data: company, error: companyError } = await supabase.from('companies').select('id').eq('id', budget.company_id)
  console.log('company:', company, companyError)

  const { data: items, error: itemsError } = await supabase.from('budget_items').select('id').eq('budget_id', budget.id)
  console.log('items:', items, itemsError)
}

test()
