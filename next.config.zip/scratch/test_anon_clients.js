import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  'https://ytqdzfmlbdomidnpvelg.supabase.co',
  'sb_publishable_n49wA8JdZCfiaWi50Nox9Q_j687t-uE'
)

async function test() {
  const { data, error } = await supabase.from('budgets').select(`
    id, status, 
    clients (name, cuit, address)
  `).limit(1)
  console.log('Anon read data:', JSON.stringify(data, null, 2))
  console.log('Anon read error:', error)
}

test()
